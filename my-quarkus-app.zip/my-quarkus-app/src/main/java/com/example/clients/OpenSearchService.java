// package com.example.clients;
package com.example.clients;


// import org.opensearch.client.OpenSearchClient;
import org.opensearch.client.opensearch;
import org.opensearch.client.RestClient;
import org.opensearch.client.RestClientBuilder;
import org.opensearch.client.RestHighLevelClient;

public class OpenSearchService {

    private OpenSearchClient client;

    public OpenSearchService() {
        RestClientBuilder builder = RestClient.builder(
            // Provide your OpenSearch server URL here
            new HttpHost("10.88.0.1", 9200, "https"));

        this.client = new RestHighLevelClient(builder);
    }

    public OpenSearchClient getClient() {
        return client;
    }

    // Add other methods for interacting with OpenSearch
}

